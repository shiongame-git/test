"""Center-of-gravity calculations for a packed container.

Boxes are assumed to have uniform density. The calculation includes only
successfully placed boxes and uses each box's geometric center as its center
of mass. Coordinates follow the project's convention: x/y/z are the minimum
corner of a box, and dimensions are w/h/d.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import sqrt

from .model import PackingResult


@dataclass(frozen=True, slots=True)
class CenterOfGravity:
    """Volume-weighted center of gravity in container coordinates."""

    x: float
    y: float
    z: float


def calculate_center_of_gravity(result: PackingResult) -> CenterOfGravity | None:
    """Return the volume-weighted center of placed boxes, or ``None`` if empty."""
    if type(result) is not PackingResult:
        raise TypeError("result must be a PackingResult")

    total_volume = 0
    weighted_x = 0.0
    weighted_y = 0.0
    weighted_z = 0.0

    for placement in result.placements:
        point = placement.position
        if point is None:
            continue
        volume = placement.box.volume
        weighted_x += (point.x + placement.box.w / 2.0) * volume
        weighted_y += (point.y + placement.box.h / 2.0) * volume
        weighted_z += (point.z + placement.box.d / 2.0) * volume
        total_volume += volume

    if total_volume == 0:
        return None
    return CenterOfGravity(
        weighted_x / total_volume,
        weighted_y / total_volume,
        weighted_z / total_volume,
    )


def calculate_center_distance(result: PackingResult) -> float | None:
    """Return CoG distance from the container's geometric center.

    The result is in the same length units as the container dimensions. Returns
    ``None`` when no boxes have been placed.
    """
    center = calculate_center_of_gravity(result)
    if center is None:
        return None

    container = result.container
    dx = center.x - container.W / 2.0
    dy = center.y - container.H / 2.0
    dz = center.z - container.D / 2.0
    return sqrt(dx * dx + dy * dy + dz * dz)


def calculate_balance_distance(result: PackingResult) -> float | None:
    """Distance from the low, horizontal center used by the Unity GA.

    The target is (container.W / 2, 0, container.D / 2): centered on the
    floor and kept low. Boxes are volume-weighted, assuming uniform density.
    """
    center = calculate_center_of_gravity(result)
    if center is None:
        return None
    container = result.container
    dx = center.x - container.W / 2.0
    dy = center.y
    dz = center.z - container.D / 2.0
    return sqrt(dx * dx + dy * dy + dz * dz)
